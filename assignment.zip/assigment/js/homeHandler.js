document.addEventListener("DOMContentLoaded", () => {
 const input1El = document.querySelector('#input1');
 const searchResultsEl = document.querySelector('#searchResults');

 // Retrieve cookie value on DOM ready
 const storedInput = document.cookie.match(/storedInput=(\w+)/)?.[1];
 if (storedInput) {
     input1El.value = storedInput;
 }

 // Submit event handler
 const dataInputForm = document.getElementById('dataInputForm');
 dataInputForm.addEventListener("submit", async e => {
     // Prevent default form behavior
     e.preventDefault();
     
     const formData = new FormData(e.target);
     const body = Object.fromEntries([...formData]);

     try {
         setCookieValue('storedInput', body['input1']);
         
         const cookieValues = document.cookie.split('; ')
             .filter(cv => cv.startsWith('storedInput='))
             .map(cv => cv.slice('storedInput='.length));

         const filteredItems = cookieValues.some(item => item === body['input1']) ? [...new Set([...searchResultsEl.innerHTML.trim().split('\n'), body['input1']])] : [];
         renderSearchResults(filteredItems);
     } catch (err) {
         console.error(err);
     }
 });

 // Clear cookies event handler
 const clearCookiesBtn = document.querySelector('#clearCookies');
 clearCookiesBtn.onclick = () => {
     deleteCookie('storedInput');
 };

  // Log out event handler
  const logOutBtn = document.querySelector('#redirectToLogin');
  logOutBtn.onclick = () =>{
   console.log('hgfgh');
  }
 });