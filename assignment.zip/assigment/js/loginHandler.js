const loginForm = document.getElementById('loginForm');

// Submit event handler
loginForm.addEventListener("submit", async e => {
    // Prevent default form behavior
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const body = Object.fromEntries([...formData]);

    try {
        const res = await fetch('/api/auth', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
        });
        
        if (!res.ok) throw Error(`Error ${res.status}: ${await res.text()}`);
        
        window.location.href = '/page2.html';
    } catch (err) {
        console.error(err);
    }
});
