const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Login endpoint
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    fs.readFile(path.join(__dirname, 'credentials.json'), 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading credentials file:', err);
            res.status(500).send('Error reading credentials');
            return;
        }
        const credentials = JSON.parse(data);
        const userCredentials = credentials.find(cred => cred[email] === password);
        if (userCredentials) {
            res.cookie('loggedIn', true);
            res.redirect('/home');
        } else {
            res.status(401).send('Invalid email or password');
        }
    });
});

// Home page endpoint
app.get('/home', (req, res) => {
    if (!req.cookies.loggedIn) {
        res.redirect('/login.html');
    } else {
        res.sendFile(path.join(__dirname, 'public', 'home.html'));
    }
});

// Logout endpoint
app.get('/logout', (req, res) => {
    res.clearCookie('loggedIn');
    res.redirect('/login.html');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
