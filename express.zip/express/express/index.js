const express = require("express");
const { config } = require("dotenv");
const { ironSession } = require("iron-session/express");
const validateUser = require("./utils/ValidateUser");

config();
const app = express();

app.use(express.json());
var session = ironSession({
  cookieName: "access_token",
  password: process.env.SECRET_COOKIE_PASSWORD,
  cookieOptions: {
    secure: process.env.NODE_ENV === "production",
  },
});

app.use(session);

// auth routes
try {
  app.get("/", validateUser, (req, res) => {
    res.sendFile(process.cwd() + "/templates/index.html");
  });
} catch (error) {
  console.log(error);
}

try {
  app.post("/auth/login", async (req, res) => {
    // password validation is not implemented
    console.log("login");
    req.session.user = "user";
    await req.session.save();
    res.redirect("/");
  });
} catch (error) {}

try {
  app.post("/auth/logout", async (req, res) => {
    // password validation is not implemented
    console.log("logout");
    req.session.destroy();
    res.redirect("/");
  });
} catch (error) {}

// starting application in a port
try {
  const port = process.env.PORT;
  app.listen(port, () => {
    console.log(`application is us and running at port ${port}`);
  });
} catch (error) {
  console.log("error starting application");
}
