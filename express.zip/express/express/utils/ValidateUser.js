const validateUser = (req, res, next) => {
  try {
    if (req.session.user === undefined) {
      throw new Error("user is not logged in");
    } else {
      next();
    }
  } catch (error) {
    res.sendFile(process.cwd() + "/templates/login.html");
  }
};

module.exports = validateUser;
